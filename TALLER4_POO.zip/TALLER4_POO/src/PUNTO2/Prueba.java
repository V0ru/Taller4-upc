package Punto2;

import java.util.Scanner;

public class Prueba {
    public static void main(String[] args) {
        Cuenta Cuenta=new Cuenta();
        Scanner entrada=new Scanner (System.in); 
        System.out.println("Escriba su numero de cuenta: ");
        int noCuenta= entrada.nextInt();
        Cuenta.setNumeroCuenta(noCuenta);
        System.out.println("Escriba su nombre(usuario de cuenta): ");
        String nombre= entrada.next();
        Cuenta.setNombreCliente(nombre);
        System.out.println("Escriba su saldo actual de la cuenta: ");
        double saldo= entrada.nextDouble();
        Cuenta.setSaldo(saldo);
        
        System.out.println("-------------");
        System.out.println("1. retirar");
        System.out.println("2. consignar");
        System.out.println("-------------");
        
        int op=entrada.nextInt();
        if (op==1) {
            retirar(Cuenta);
            }
        else if (op==2){
            consignar(Cuenta);
            } 
        }
    public static void consignar(Cuenta Cuenta) {
        Scanner entrada= new Scanner(System.in);
        System.out.println("Digite la cantidad que desea consignar : ");
        double cantidad=entrada.nextDouble();
        Cuenta.setSaldo(Cuenta.getSaldo()+cantidad);
        System.out.printf("Su nuevo saldo es:  %.2f%n",Cuenta.getSaldo());
    }
    public static void retirar(Cuenta Cuenta) {
        Scanner entrada=new Scanner (System.in);
        System.out.println("Digite la cantidad que desea retirar: ");
        double cantidad=entrada.nextDouble();
        Cuenta.setSaldo(Cuenta.getSaldo()-cantidad);
        System.out.printf("Su nuevo saldo es:  %.2f%n",Cuenta.getSaldo());
    }
}
