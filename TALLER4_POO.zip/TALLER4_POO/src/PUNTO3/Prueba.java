package PUNTO3;
import Modelo.Informe;
import modelo.*;
public class Prueba {
    public static void main(String[] args) {
        Informe Informe = new Informe();
        Informe.leerVentas(); 
        imprimir(Informe);
    }
    public static void imprimir(Informe Informe){
        System.out.printf("Su promedio es: %.2f\n",Informe.promedio());
        System.out.println("Su total de ventas es : "+Informe.sumaTotal());
        System.out.println("Mes con mas ventas :"+Informe.mayorVentas());
        System.out.println("Mes con menos ventas:"+Informe.menorVentas());
    }
}
