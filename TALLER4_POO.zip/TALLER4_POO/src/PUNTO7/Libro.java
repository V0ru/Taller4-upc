package PUNTO7;
public class Libro {
    private String Titulo;
    private String Primernombre;
    private String Segundonombre;
    private String Primerapellido;
    private String Ciudad;
    private String Pais;
    private int Edicion;
    private String Editorial;
    private String Isbn;
    private String Fecha;
    private int Paginas;
    public Libro(){
        
    }
    public String getTitulo() {
        return Titulo;}
    public void setTitulo(String titulo) {
        this.Titulo = titulo;
    }
    public String getprimernombre(){
        return Primernombre;}
    public void setprimernombre(String primer_nombre){
        this.Primernombre = primer_nombre;
    }
    public String getSegundonombre() {
        return Segundonombre;}
    public void setSegundonombre(String segundo_nombre){
        this.Segundonombre=segundo_nombre;
    }
    public String getPrimerapellido(){
        return Primerapellido;}
    public void setPrimerapellido(String primer_apellido){
        this.Primerapellido=primer_apellido;
    }
    public String getCiudad(){
        return Ciudad;}
    public void setCiudad(String ciudad_){
        this.Ciudad=ciudad_;
    }
    public String getPais(){
        return Pais;}
    public void setPais(String Pais_){
        this.Pais=Pais_;
    }
    public String getEditorial(){
        return Editorial;}
    public void setEditorial(String editorial_){
        this.Editorial=editorial_;
    }
    public String getIsbn(){
        return Isbn;}
    public void setIsbn(String Isbn_){
        this.Isbn=Isbn_;
    }
    public String getFecha(){
        return Fecha;}
    public void setFecha(String Fecha_){
        this.Fecha=Fecha_;
    }
    public int getEdicion(){
        return Edicion;}
    public void setEdicion(int Edicion_){
        this.Edicion=Edicion_;
    }
    public int getPaginas(){
        return Paginas;}
    public void setPaginas(int Paginas_){
        this.Paginas=Paginas_;}
    }