package PUNTO4;
public class Prueba {
    public static void main(String[] args) {
                                       //Largo,Ancho,Alto
        System.out.println(new Habitacion(3, 14, 3).elString());
    }   
}