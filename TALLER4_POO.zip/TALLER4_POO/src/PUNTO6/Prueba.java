package PUNTO6;
public class Prueba {
    public static void main(String[] args) {
        System.out.println(new Ecuacion(4, 4, 6, 7).elString());
    }  
}
