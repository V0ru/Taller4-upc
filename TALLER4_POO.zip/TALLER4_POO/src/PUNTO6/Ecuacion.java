package PUNTO6;

public class Ecuacion {

    private int a;
    private int b;
    private int c;
    private int y;
    
    public int geta(){
        return a;}
    public void seta(int a){
        this.a = a;}
    public int getb(){
        return b;}
    public void setb(int b){
        this.b = b;}
    public int getc(){
        return c;}
    public void setc(int c){
        this.c = c;}
    public int gety(){
        return y;}
    public void sety(int y){
        this.y = y;} 
    public Ecuacion(int a, int b, int c, int y){
        this.a = a;
        this.b = b;
        this.c = c;
        this.y = y;
    }
    public int getx(){
        int x = a*(y*y^2)+b*y+c;
        return x;
    }
    public String elString(){
        return "La ecuacion x=("+ a + ")("+ b + "^2)+(" + b + ")(" + y + ")+" + c + " Este es el valor de X "+getx();
    }
}