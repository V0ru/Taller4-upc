package PUNTO1;
public class Prueba {
    public static void main(String[] args) {
        Carro coche1 = new Carro("Blanco", "Ferrari", "Daytona", 5000, 2, "JPG26");
        Carro coche2 = new Carro("Amarillo", "Toyota", "TXL", 800, 4, "PYT267");
        Carro coche3 = new Carro("Verde", "Maza", "Mazda3", 400, 4, "DLV795");
        System.out.println(coche1.elString());
        System.out.println(coche2.elString());
        System.out.println(coche3.elString());
    }   
}
