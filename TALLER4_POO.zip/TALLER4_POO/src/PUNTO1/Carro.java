package PUNTO1;
public class Carro {
    private String color;
    private String marca;
    private String modelo;
    private int NumeroCaballos;
    private int NumeroPuertas;
    private String matricula;
    public Carro(String color,String marca,String modelo,int NumeroCaballos,int NumeroPuertas,String matricula){
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.NumeroCaballos = NumeroCaballos;
        this.NumeroPuertas = NumeroPuertas;
        this.matricula = matricula;
    }
    public String getColor() {
        return color;}
    public void setColor(String color) {
        this.color = color;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public int getNumeroCaballos() {
        return NumeroCaballos;
    }
    public void setNumeroCaballos(int NumeroCaballos) {
        this.NumeroCaballos = NumeroCaballos;
    }
    public int getNumeroPuertas() {
        return NumeroPuertas;
    }
    public void setNumeroPuertas(int NumeroPuertas) {
        this.NumeroPuertas = NumeroPuertas;
    }
    public String getMatricula() {
        return matricula;
    }
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    public String elString(){
        return "Marca: "+marca+"; color: "+color+"; modelo: "+modelo+"; numero de caballos: "+NumeroCaballos+
                "; numero de puertas: "+NumeroPuertas+"; matricula: "+matricula+";";
    }
}