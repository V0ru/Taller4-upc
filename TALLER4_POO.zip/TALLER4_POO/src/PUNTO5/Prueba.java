package PUNTO5;
public class Prueba {
    public static void main(String[] args) {
        System.out.println(new Triangulo(5, 8).elString());
    }
}
