package PUNTO5;
public class Triangulo {
    private int Altura;
    private int Base;
    private double Area;
    private double Perimetro;
    private double AnguloVertice;
    private double Longitud;
    public Triangulo(int base, int altura){
        this.Base=base;
        this.Altura=altura;
    }
    public int getAltura() {
        return Altura;
    }
    public void setAltura(int base) {
        this.Altura = Altura;
    }
    public int getBase() {
        return Base;
    }
    public void setBase(int altura) {
        this.Base = altura;
    }
    public double getArea(){
        return Altura*Base/2;
    }
    public double getLongitud(){
        double num =  Math.pow(Altura, 2) +  Math.pow((Base/2), 2);;
        return Math.sqrt(num);
    }
    public double getPerimetro(){
        return (2*getLongitud())+Base;
    }
    public double getAnguloVertice(){
        double basee = (double) Base/2;
        double alturaa = (double) Altura/basee;
        double M = (double)Math.atan(alturaa);
        return M*180/Math.PI;
    }
    public String elString(){
        return "Este es su Area : "+getArea()+"\nLa longitud de sus lados es : "+getLongitud()+
                " \nEste es su perimetro : "+getPerimetro()+" \nEl valor de su angulo vertice es : "+getAnguloVertice();
    }
}